export declare class DeflyWalletConnectModalPendingMessageSection extends HTMLElement {
    constructor();
    connectedCallback(): void;
    onClose(): void;
    addAudioForConnection(): void;
}
