export declare class DeflyWalletConnectModalInformationSection extends HTMLElement {
    constructor();
    onClickDownload(): void;
}
