export declare class DeflyWalletConnectModal extends HTMLElement {
    constructor();
}
