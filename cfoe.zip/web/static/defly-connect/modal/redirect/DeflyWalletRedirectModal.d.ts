export declare class DeflyWalletRedirectModal extends HTMLElement {
    constructor();
    connectedCallback(): void;
    onClose(): void;
}
