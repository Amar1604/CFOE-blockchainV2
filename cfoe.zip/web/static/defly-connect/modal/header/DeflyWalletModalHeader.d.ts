export declare class DeflyWalletModalHeader extends HTMLElement {
    constructor();
    onClose(): void;
}
