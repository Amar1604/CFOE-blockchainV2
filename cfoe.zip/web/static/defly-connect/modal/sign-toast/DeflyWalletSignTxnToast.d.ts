export declare class DeflyWalletSignTxnToast extends HTMLElement {
    constructor();
    renderLottieAnimation(): void;
}
