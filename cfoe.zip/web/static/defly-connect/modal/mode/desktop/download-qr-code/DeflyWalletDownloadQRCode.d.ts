export declare class DeflyWalletDownloadQRCode extends HTMLElement {
    constructor();
    connectedCallback(): void;
}
