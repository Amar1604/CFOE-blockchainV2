export declare class DeflyWalletModalDesktopMode extends HTMLElement {
    constructor();
    connectedCallback(): void;
    handleChangeView(): void;
    handleAccordion(event: MouseEvent): void;
    renderQRCode(): void;
    onClickDownload(): void;
    onClickCopy(): void;
    onClickBack(): void;
}
