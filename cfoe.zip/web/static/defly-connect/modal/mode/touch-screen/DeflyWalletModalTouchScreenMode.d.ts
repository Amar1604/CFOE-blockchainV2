export declare class DeflyWalletModalTouchScreenMode extends HTMLElement {
    constructor();
    onClickLaunch(): void;
}
