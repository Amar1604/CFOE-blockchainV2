export declare class DeflyWalletSignTxnModal extends HTMLElement {
    constructor();
}
