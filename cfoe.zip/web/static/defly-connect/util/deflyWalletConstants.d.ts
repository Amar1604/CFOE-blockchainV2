declare const DEFLY_WALLET_APP_DEEP_LINK: string;
declare const DEFLY_DOWNLOAD_URL = "https://defly.app/";
export { DEFLY_WALLET_APP_DEEP_LINK, DEFLY_DOWNLOAD_URL };
