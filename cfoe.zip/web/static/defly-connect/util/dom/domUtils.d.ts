declare function waitForElementCreatedAtShadowDOM(element: Element, className: string): Promise<Element>;
export { waitForElementCreatedAtShadowDOM };
