declare function generateSimpleId(): number;
export { generateSimpleId };
