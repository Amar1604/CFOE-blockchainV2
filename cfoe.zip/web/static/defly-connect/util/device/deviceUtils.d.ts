declare function isAndroid(): boolean;
declare function isIOS(): boolean;
declare function isMobile(): boolean;
/**
 * Detects the browser name
 * @returns {BrowserName} Browser name
 */
declare function detectBrowser(): string | null;
export { isAndroid, isIOS, isMobile, detectBrowser };
