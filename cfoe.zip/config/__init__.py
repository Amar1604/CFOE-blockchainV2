"""Config package for CfoE"""
